BEWERBUNGSPROFIS – WEBSITE STARTEN (nur mit dem Handy)
========================================================

DATEIEN
- index.html: die eigentliche, mobiloptimierte Website
- impressum.html: auszufüllende Impressum-Vorlage
- datenschutz.html: auszufüllende Datenschutz-Vorlage

VOR DER VERÖFFENTLICHUNG
1. Öffne index.html in einem Texteditor oder Code-Editor.
2. Die Kontakt-E-Mail wurde bereits auf bewerbungs.profis1@gmail.com gesetzt.
3. Ersetze den Beispiel-WhatsApp-Link https://wa.me/491234567890 durch deinen WhatsApp-Link im internationalen Format ohne +, Leerzeichen oder Sonderzeichen. Beispiel: deutsche Nummer 0176 12345678 -> wa.me/4917612345678.
4. Prüfe die Preise (19 €, 25 €, 40 €), Leistungen und den Businessnamen.
5. Fülle impressum.html und datenschutz.html vollständig passend zu deiner Situation aus. Diese Vorlagen sind keine Rechtsberatung. Veröffentliche keine leeren oder falschen Pflichtangaben.
6. Prüfe die Seite am Handy und klicke alle Kontaktlinks durch.

KOSTENLOSE VERÖFFENTLICHUNG MIT DEM HANDY – EINFACHE MÖGLICHKEIT
Option A: Netlify (statische Website)
1. Erstelle ein Konto bei Netlify: https://app.netlify.com/
2. Öffne Netlify Docs zur manuellen Bereitstellung: https://docs.netlify.com/site-deploys/create-deploys/
3. Für die manuelle Bereitstellung muss der Ordner mit den Website-Dateien hochgeladen werden. Falls dein Handy keine Ordner hochladen kann, entpacke die ZIP-Datei in der Dateien-App und nutze einen Browser/Dateimanager, der Ordner-Upload unterstützt, oder nutze Option B.
4. Nach erfolgreicher Veröffentlichung stellt Netlify eine öffentliche Adresse bereit. Die kostenlosen Konditionen und Funktionen können sich ändern; prüfe sie beim Anbieter.

Option B: GitHub Pages
1. Öffne https://github.com/ und erstelle kostenlos ein Konto.
2. Erstelle ein neues öffentliches Repository, z. B. bewerbungsprofis-website.
3. Lade index.html, impressum.html und datenschutz.html einzeln über Add file -> Upload files hoch.
4. Öffne Settings -> Pages.
5. Wähle unter Build and deployment die Bereitstellung von einem Branch, wähle main und / (root), dann Save.
6. Warte, bis GitHub Pages die öffentliche Website-Adresse anzeigt. Die Menübezeichnungen können sich ändern.

WICHTIG
- Kostenlose Hosting-Angebote und ihre Limits können sich ändern.
- Eigene Domain ist optional und kann Geld kosten.
- Der HTML-Mailkontakt öffnet beim Besucher die E-Mail-App und adressiert die Anfrage an bewerbungs.profis1@gmail.com. Er ist kein serverseitiges Formular.
- Eine echte geschäftliche Website in Deutschland kann rechtliche Informationspflichten auslösen. Lass Impressum und Datenschutz vor Veröffentlichung passend prüfen.
- Wenn du noch kein angemeldetes Gewerbe hast, prüfe vor dem Start, welche Anmeldung und steuerlichen Pflichten für deine Tätigkeit gelten.
